DD Events – Divine Delights
===========================

This package contains your single-page website (light gold & white theme).

Files included:
- index.html
- images/logo.png        (placeholder — replace with your actual logo file)
- images/hero.jpg        (placeholder — replace with your chosen hero image)
- images/gallery1.jpg .. gallery10.jpg  (place your gallery photos here)

How to replace with your real images:
1. Download and unzip this package.
2. Open the 'images' folder and replace the placeholder files with your real images.
   Keep the same filenames (e.g., hero.jpg, logo.png, gallery1.jpg, ...).
3. Upload the entire folder to a hosting provider (Netlify Drop, GitHub Pages, or any web host).
   - Netlify Drop: drag & drop the unzipped folder at https://app.netlify.com/drop
   - GitHub Pages: create a repo, push files, enable Pages
4. Optional: To use a custom domain, purchase a domain and point it to your host. I can help with that.

If you'd like, re-upload your real image files here (as a zip) and I will rebuild this package with your images embedded and provide the downloadable zip.
